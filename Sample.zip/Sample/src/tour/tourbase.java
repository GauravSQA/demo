package tour;

import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.SkipException;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import base.SuiteBase;
import utility.Read_XLS;
import utility.SuiteUtility;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class tourbase extends base.SuiteBase{
	
	Read_XLS FilePath = null;
	String SheetName = null;
	String SuiteName = null;
	String ToRunColumnName = null;	
	protected static WebDriver driver = null;
	 private final String filePath = "D:\\test.html";
	 public static ExtentReports extent;
	 //public static String URL = "http://www.qaobassociation.com/en_no";
	 //public static String URL = "http://demosite.promocan.com/en_ca";
	 //public static String URL = "http://www.aakronline.com/en_us";
	 public static String URL = "http://newtours.demoaut.com/index.php";
	// new instance
		//ExtentReports extent = new ExtentReports("D:\\test.html", true);
	
	@BeforeSuite
	public void checkSuiteToRun() throws IOException{		
		//Called init() function from SuiteBase class to Initialize .xls Files
		init();			
		//To set TestSuiteList.xls file's path In FilePath Variable.
		FilePath = TestSuiteListExcel;
		SheetName = "SuitesList";
		SuiteName = "SuiteOne";
		ToRunColumnName = "SuiteToRun";
	
		extent = new ExtentReports(filePath, true);
	

		//Bellow given syntax will Insert log In applog.log file.
		Add_Log.info("Execution started for TransactionBase.");
		
		//If SuiteToRun !== "y" then SuiteOne will be skipped from execution.
		if(!SuiteUtility.checkToRunUtility(FilePath, SheetName,ToRunColumnName,SuiteName)){			
			Add_Log.info("SuiteToRun = N for "+SuiteName+" So Skipping Execution.");
			//To report SuiteOne as 'Skipped' In SuitesList sheet of TestSuiteList.xls If SuiteToRun = N.
			SuiteUtility.WriteResultUtility(FilePath, SheetName, "Skipped/Executed", SuiteName, "Skipped");
			//It will throw SkipException to skip test suite's execution and suite will be marked as skipped In testng report.
			throw new SkipException(SuiteName+"'s SuiteToRun Flag Is 'N' Or Blank. So Skipping Execution Of "+SuiteName);
		}
		//To report SuiteOne as 'Executed' In SuitesList sheet of TestSuiteList.xls If SuiteToRun = Y.
		SuiteUtility.WriteResultUtility(FilePath, SheetName, "Skipped/Executed", SuiteName, "Executed");	
		
		driver = new FirefoxDriver();
		//To set time out 15 seconds.
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		//To maximize the browser.
		driver.manage().window().maximize();
		
		driver.get(URL);
		
	}		
	
	
	@AfterSuite
	public void genRep()
	{
		
		//extent.flush();
	}
}

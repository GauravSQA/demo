package tour;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.SkipException;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.mysql.jdbc.Driver;
import utility.Read_XLS;
import utility.SuiteUtility;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;


public class login extends tourbase {
	
	Read_XLS FilePath = null;
	String SheetName = null;
	String TestCaseName = null;	
	String ToRunColumnNameTestCase = null;
	String ToRunColumnNameTestData = null;
	String TestDataToRun[]=null;
	static boolean TestCasePass=true;
	static int DataSet=-1;	
	static boolean Testskip=false;
	static boolean Testfail=false;
	SoftAssert s_assert =null;	
	private static WebElement element = null;
	public String Result;
		

	
	@Test(dataProvider="LoginData")
	public WebElement Login(String UserName,String Password) throws InterruptedException, IOException
	{
				
		Thread.sleep(2000);
			
		System.out.println("TEST1");
		
		driver.findElement(By.name("userName")).sendKeys(UserName);
		
		driver.findElement(By.name("userName")).sendKeys(UserName);
		
		driver.findElement(By.name("userName")).click();
		
		Thread.sleep(2000);		 
		
        return element;
     
	}
	
	
	public void verify_wishlist() throws InterruptedException
	{
		
		driver.get(URL+"/wish-list");
		
		Thread.sleep(2000);
		
		//WebElement webElement = driver.findElement(By.xpath("//form[@id='form1']/div[4]"));

		//Get list of  elements using ClassName
		//List<WebElement> list = webElement.findElements(By.className("pro-box"));
		
		List<WebElement> optionCount = driver.findElements(By.className("pro-box"));
		System.out.println(optionCount.size());
		Result = String.valueOf(optionCount.size());
		//Result=driver.findElement(By.xpath(".//div/div/div[3]/div/div[1]")).getText();
		
		System.out.println(Result);
	
	}
	
	public void Remove_wishlist() throws InterruptedException
	{
		
		//driver.findElement(By.xpath("/ul/li[3]/a/span[2]/span")).click();
		driver.findElement(By.cssSelector(".fa.fa-trash-o")).click();
				
		driver.findElement(By.xpath("html/body/div[4]/div/div/div[3]/button[2]")).click();
		
		driver.findElement(By.xpath(".//div/div/div[3]/button[2]")).click();
		
		Thread.sleep(1000);
		
		driver.findElement(By.xpath(".//*[@id='js-wish-list-queue-list']/div[3]/a[2]")).click();
	
		
	}
	
	
	@DataProvider
	public Object[][] LoginData(){
		//To retrieve data from Data 1 Column,Data 2 Column,Data 3 Column and Expected Result column of SuiteOneCaseOne data Sheet.
		//Last two columns (DataToRun and Pass/Fail/Skip) are Ignored programatically when reading test data.
		return SuiteUtility.GetTestDataUtility(FilePath, TestCaseName);
		
		
	}	
	
}
